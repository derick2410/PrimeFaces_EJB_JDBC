/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.csd.services;

import edu.gmu.csd.bean.Student;
import edu.gmu.csd.dao.StudentDao;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author Derick Augustine Coutinho
 */
@ManagedBean
@RequestScoped
public class StudentService {

    private ArrayList<Student> studentsSurvey;

    public ArrayList<Student> getStudentsSurvey() {
        return studentsSurvey;
    }

    public void setStudentsSurvey(ArrayList<Student> studentsSurvey) {
        this.studentsSurvey = studentsSurvey;
    }

    public void saveData(Student student) {
        StudentDao studentDao = new StudentDao();
        studentDao.saveStudentSurveyInfo(student);
    }

    public String retrieveStudentsSurvey() {
        StudentDao studentDao = new StudentDao();
        ArrayList<Student> studentInfoList = studentDao.retrieveStudentInfos();
        setStudentsSurvey(studentInfoList);

        return "listOfStudentSurveys";
    }
}
