/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.csd.dao;

import edu.gmu.csd.bean.Student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author DELL
 */
public class StudentDao {

    final private String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
    final private String DATABASE_URL = "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g";
    final private String USER_NAME = "dcoutinh";
    final private String PASSWORD = "JesuMary25";

    public Connection getConnection() throws Exception {
        Class.forName(DRIVER_NAME);
        Connection conn = DriverManager.getConnection(DATABASE_URL, USER_NAME,
                PASSWORD);
        return conn;
    }

    public boolean saveStudentSurveyInfo(Student student) {
        boolean isUniqueConstraintViolated = false;

        PreparedStatement preparedStatement = null;
        Connection sqlConnection = null;
        try {
            sqlConnection = getConnection();

            preparedStatement = sqlConnection
                    .prepareStatement("insert into studsurveyinfo values (?,?,?,?,?,?,?,?,?,?,?,?)");

            preparedStatement.setString(1, student.getFirstName());
            preparedStatement.setString(2, student.getLastName());
            preparedStatement.setString(3, student.getStreetAddress());
            preparedStatement.setString(4,
                    student.getZip());
            preparedStatement.setString(5, student.getCity());
            preparedStatement.setString(6, student.getState());
            preparedStatement.setString(7, student.getTelNumber());
            preparedStatement.setString(8, student.getEmail());
            preparedStatement.setString(9, new SimpleDateFormat("MMM, dd yyyy").format(student.getDateOfSurvey()));
            preparedStatement.setString(10, student.getStringAppendedCampusLike());
            preparedStatement.setString(11, student.getUniversityInterest());
            preparedStatement.setString(12, student.getSchoolRecommend());

            preparedStatement.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();

            if (StringUtils.contains(e.getMessage(), "unique constraint")) {
                isUniqueConstraintViolated = true;
            }
        } finally {
            try {
                preparedStatement.close();
                sqlConnection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return isUniqueConstraintViolated;
    }

    public ArrayList<Student> retrieveStudentInfos() {
        ArrayList<Student> studentInfos = null;

        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;
        Connection sqlConnection = null;
        Student student = null;
        try {
            studentInfos = new ArrayList<Student>();
            sqlConnection = getConnection();

            String query = "SELECT * FROM studsurveyinfo";
            preparedStatement = sqlConnection.prepareStatement(query);

            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                student = new Student();
                student.setFirstName(resultSet.getString("firstname"));
                student.setLastName(resultSet.getString("lastname"));
                student.setStreetAddress(resultSet.getString("streetaddress"));
                student.setZip(resultSet.getString("zipcode"));
                student.setCity(resultSet.getString("city"));
                student.setState(resultSet.getString("state"));
                student.setTelNumber(resultSet.getString("telnum"));
                student.setEmail(resultSet.getString("email"));

                DateFormat format = new SimpleDateFormat("MMM, dd yyyy");
                Date surveyDate = format.parse(resultSet.getString("surveydate"));
                student.setDateOfSurvey(surveyDate);

                student.setStringAppendedCampusLike(resultSet.getString("likings"));
                student.setUniversityInterest(resultSet.getString("interest"));
                student.setSchoolRecommend(resultSet.getString("recomend"));

                studentInfos.add(student);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                resultSet.close();
                preparedStatement.close();
                sqlConnection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return studentInfos;
    }
}
