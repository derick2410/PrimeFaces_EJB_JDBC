/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.gmu.csd.bean;

import edu.gmu.csd.processor.DataProcessor;
import edu.gmu.csd.services.StudentService;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author Derick Augustine Coutinho
 */
@ManagedBean
@RequestScoped
public class Student {

    private String firstName;
    private String lastName;
    private String streetAddress;
    private String city;
    private String state;
    private String zip;
    private String telNumber;
    private String email;
    private Date dateOfSurvey;
    private String[] campusLike;
    private String stringAppendedCampusLike;
    private String universityInterest;
    private String schoolRecommend;
    private Date possStartDateOfSem;
    private String raffle;
    private String addComm;

    private final String schoolRecommendString = "Very Likely,Likely,Unlikely";
    private final String[] schoolRecommendArray = schoolRecommendString.split(",");

    private WinningResult winningResult;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        if (zip.length() == 5) {
            for (Map.Entry<String, String> entry : getMap().entrySet()) {
                if (entry.getKey().equals(zip)) {
                    String[] cityState = entry.getValue().split("-");
                    this.city = cityState[0];
                    this.state = cityState[1];
                    break;
                } else {
                    this.city = "";
                    this.state = "";
                }
            }
        }
        this.zip = zip;
    }

    public Map<String, String> getMap() {
        Map<String, String> zipCityState = new HashMap<String, String>();
        zipCityState.put("22312", "Alexandria-VA");
        zipCityState.put("22030", "Fairfax-VA");
        zipCityState.put("22301", "Tysons Corner-MD");
        zipCityState.put("20148", "Ashburn-VA");

        return zipCityState;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDateOfSurvey() {
        return dateOfSurvey;
    }

    public void setDateOfSurvey(Date dateOfSurvey) {
        this.dateOfSurvey = dateOfSurvey;
    }

    public String[] getCampusLike() {
        return campusLike;
    }

    public void setCampusLike(String[] campusLike) {
        this.campusLike = campusLike;
    }

    public String getStringAppendedCampusLike() {
        return stringAppendedCampusLike;
    }

    public void setStringAppendedCampusLike(String stringAppendedCampusLike) {
        this.stringAppendedCampusLike = stringAppendedCampusLike;
    }

    public String getUniversityInterest() {
        return universityInterest;
    }

    public void setUniversityInterest(String universityInterest) {
        this.universityInterest = universityInterest;
    }

    public String getSchoolRecommend() {
        return schoolRecommend;
    }

    public void setSchoolRecommend(String schoolRecommend) {
        this.schoolRecommend = schoolRecommend;
    }

    public Date getPossStartDateOfSem() {
        return possStartDateOfSem;
    }

    public void setPossStartDateOfSem(Date possStartDateOfSem) {
        this.possStartDateOfSem = possStartDateOfSem;
    }

    public String getRaffle() {
        return raffle;
    }

    public void setRaffle(String raffle) {
        this.raffle = raffle;
    }

    public String getAddComm() {
        return addComm;
    }

    public void setAddComm(String addComm) {
        this.addComm = addComm;
    }

    public WinningResult getWinningResult() {
        return winningResult;
    }

    public void setWinningResult(WinningResult winningResult) {
        this.winningResult = winningResult;
    }

    public String validateForm() {
        String fwdToXhtml = null;

        FacesContext facesContext = FacesContext.getCurrentInstance();

        if (getPossStartDateOfSem().before(getDateOfSurvey())) {
            FacesMessage errorMessage
                    = new FacesMessage("Semester start date must be after survey date");
            errorMessage.setSeverity(FacesMessage.SEVERITY_ERROR);
            facesContext.addMessage("form:possStartDateOfSem", errorMessage);
        }

        if (!facesContext.getMessages().hasNext()) {
            Student student = new Student();
            student.setFirstName(getFirstName());
            student.setLastName(getLastName());
            student.setStreetAddress(getStreetAddress());
            student.setCity(getCity());
            student.setState(getState());
            student.setZip(getZip());
            student.setTelNumber(getTelNumber());
            student.setEmail(getEmail());
            student.setDateOfSurvey(getDateOfSurvey());
            student.setCampusLike(getCampusLike());
            student.setUniversityInterest(getUniversityInterest());
            student.setSchoolRecommend(getSchoolRecommend());
            student.setRaffle(getRaffle());
            student.setAddComm(getAddComm());
            
            StringBuilder like = null;
            for(String campusLikeVal: getCampusLike()) {
                like = new StringBuilder();
                like.append(campusLikeVal);
                like.append(" ");
            }
            student.setStringAppendedCampusLike(like.toString());

            StudentService studentService = new StudentService();
            studentService.saveData(student);

            WinningResult result = DataProcessor.calculateMeanStandardDeviation(getRaffle());
            setWinningResult(result);

            if (null != result && result.getMean() > 90) {
                // WinnerAcknowledgement JSP
                fwdToXhtml = "winnerAcknowledgement";
            } else {
                // SimpleAcknowledgement JSP
                fwdToXhtml = "simpleAcknowledgement";
            }
        }

        return fwdToXhtml;
    }

    public List<String> completeRecommend(String recommendPrefix) {
        List<String> matches = new ArrayList<String>();
        for (String possibleRecommend : schoolRecommendArray) {
            if (possibleRecommend.toUpperCase()
                    .startsWith(recommendPrefix.toUpperCase())) {
                matches.add(possibleRecommend);
            }
        }
        return (matches);
    }
}
